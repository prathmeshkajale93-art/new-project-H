// Owner-only: create and remove staff/reception accounts (needs the Admin SDK).
const { admin, json, verify } = require("../lib/admin");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, { error: "Method not allowed" });
  try {
    const caller = await verify(event);
    const db = admin.firestore();
    const me = await db.doc("users/" + caller.uid).get();
    if (!me.exists || me.data().role !== "owner") return json(403, { error: "Owner access required" });
    const b = JSON.parse(event.body || "{}");

    if (b.action === "create") {
      const { name, email, dept, role, password } = b;
      if (!name || !email || !/^\S+@\S+\.\S+$/.test(email)) return json(400, { error: "Enter a name and a valid email" });
      if (!["staff", "reception"].includes(role)) return json(400, { error: "Invalid access level" });
      if (!password || password.length < 8) return json(400, { error: "Password must be 8+ characters" });
      const u = await admin.auth().createUser({ email, password, displayName: name });
      await db.doc("users/" + u.uid).set({ name, email, dept: dept || "", role, createdAt: Date.now() });
      return json(200, { ok: true, uid: u.uid });
    }
    if (b.action === "delete") {
      if (!b.uid || b.uid === caller.uid) return json(400, { error: "Cannot remove this account" });
      const t = await db.doc("users/" + b.uid).get();
      if (t.exists && t.data().role === "owner") return json(400, { error: "Cannot remove an owner" });
      await admin.auth().deleteUser(b.uid).catch(() => {});
      await db.doc("users/" + b.uid).delete();
      return json(200, { ok: true });
    }
    return json(400, { error: "Unknown action" });
  } catch (e) {
    const msg = e.code === "auth/email-already-exists" ? "That email is already in use" : e.message;
    return json(e.code === 401 ? 401 : 500, { error: msg });
  }
};
