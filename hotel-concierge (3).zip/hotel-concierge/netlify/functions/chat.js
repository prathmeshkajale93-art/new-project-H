// AI Concierge. The Anthropic key lives only in Netlify environment variables.
const { admin, json, verify } = require("../lib/admin");
const FIELDS = [["name","Hotel name"],["tagline","Tagline"],["wifi","Wi-Fi (Network|Password)"],["hours","Timings & property info"],["services","Guest services"],["facilities","Facilities"],["offers","Offers"],["contacts","Contacts"],["policies","Policies"],["items","Housekeeping items"]];
const hits = new Map(); // best-effort per-instance rate limit

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, { error: "Method not allowed" });
  try {
    const user = await verify(event);
    const now = Date.now(), recent = (hits.get(user.uid) || []).filter(t => now - t < 60000);
    if (recent.length >= 12) return json(429, { error: "Too many messages. Please wait a moment." });
    hits.set(user.uid, [...recent, now]);

    const { question, history = [] } = JSON.parse(event.body || "{}");
    if (typeof question !== "string" || !question.trim() || question.length > 600) return json(400, { error: "Invalid question" });
    const snap = await admin.firestore().doc("cfg/hotel").get();
    if (!snap.exists) return json(503, { error: "Hotel not set up" });
    const H = snap.data();
    const info = FIELDS.map(([k, l]) => `${l}:\n${H[k] || "(not provided)"}`).join("\n\n");
    const convo = history.slice(-8).map(m => `${m.r === "guest" ? "Guest" : "Concierge"}: ${String(m.t).slice(0, 600)}`).join("\n");

    const system = `You are the concierge of ${H.name}. Use ONLY the hotel information provided. If the answer is not there, say you don't have that information and suggest contacting reception. Never invent details, prices, or timings. Be warm and brief. If the guest asks you to arrange something for their room, confirm and add a final line exactly "ACTION: <short request>".\n\nHOTEL INFORMATION\n${info}`;
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5", max_tokens: 500, system,
        messages: [{ role: "user", content: `${convo ? "CONVERSATION SO FAR\n" + convo + "\n\n" : ""}Guest: ${question.trim()}\n\nReply to the guest.` }]
      })
    });
    if (!r.ok) { console.error(await r.text()); return json(502, { error: "AI unavailable" }); }
    const d = await r.json();
    return json(200, { text: (d.content || []).filter(b => b.type === "text").map(b => b.text).join("\n").trim() });
  } catch (e) { return json(e.code === 401 ? 401 : 500, { error: e.message }); }
};
